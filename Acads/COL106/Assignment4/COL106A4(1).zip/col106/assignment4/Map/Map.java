package col106.assignment4.Map;

public class Map<V> {
	
	public Map() {
		// write your code here	
	}

	public void eval(String inputFileName, String outputFileName) {
		// write your code here	
	}
}
