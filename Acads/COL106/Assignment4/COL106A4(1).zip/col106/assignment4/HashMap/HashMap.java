package col106.assignment4.HashMap;
import java.util.Vector;

public class HashMap<V> implements HashMapInterface<V> {

	public HashMap(int size) {
		// write your code here
	}

	public V put(String key, V value){
		// write your code here
		return null;
	}

	public V get(String key){
		// write your code here
		return null;
	}

	public boolean remove(String key){
		// write your code here
		return false;
	}

	public boolean contains(String key){
		// write your code here
		return false;
	}

	public Vector<String> getKeysInOrder(){
		// write your code here
		return null;
	}
}
