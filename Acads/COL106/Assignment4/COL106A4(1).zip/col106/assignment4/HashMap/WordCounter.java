package col106.assignment4.HashMap;

public class WordCounter {

	public WordCounter(){
		// write your code here
	}

	public int count(String str, String word){
		// write your code here
		return 0;
	}
}
