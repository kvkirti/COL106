package col106.assignment4.WeakAVLMap;
import java.util.Vector;

public class WeakAVLMap<K extends Comparable,V> implements WeakAVLMapInterface<K,V>{

	public WeakAVLMap(){
		// write your code here
	}
	
	public V put(K key, V value){
		// write your code her 
		return null;
	}

	public V remove(K key){
		// write your code her 
		return null;
	}

	public V get(K key){
		// write your code her 
		return null;
	}

	public Vector<V> searchRange(K key1, K key2){
		// write your code her 
		return null;
	}

	public int rotateCount(){
		// write your code her 
		return 0;
	}

	public int getHeight(){
		// write your code her 
		return 0;
	}

	public Vector<K> BFS(){
		// write your code her 
		return null;
	}

}
